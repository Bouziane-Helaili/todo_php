const orderOption = document.getElementById('order');

orderOption.addEventListener('change', () => {

    document.getElementById('orderForm').submit();

})
