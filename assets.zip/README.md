Création d'un gestionnaire de fichier avec authentification et base de données.
Réalisation dans le cadre de la formation développeur Web de l'Afpa.
Fait en php procédural.
A suivre : 
- mettre un champ confirmation de mot de passe
- refaire la réalisation en poo sur le modèle MVC.
Bouziane HELAILI